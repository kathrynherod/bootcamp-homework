$(document).ready(function() {


    //game object
    var fight = {

        //initialize functions
        init: function() {
            var initialRender = true;
            var clickedBtn = "";
            this.renderDom();
            this.whenClicked();
            this.handleClicks(clickedBtn);
        },

        //write html to DOM
        renderDom: function() {

            var colMd3 = "<div class ='col-md-3 col-sm-3 col-xs-3' id='";
            var colMd4 = "<div class ='col-md-4 col-sm-4 col-xs-4' id='";
            var cDiv = "'</div>";

            if (initialRender = true) {
                //create the char columns
                for (i = 1; i < 5; i++) {
                    $("#choose-char").append(colMd3 + i + cDiv);
                }
                //char names
                $("#1").append("<h4 id='h1'>" + characters.c1.name + "</h4>");
                $("#2").append("<h4 id='h2'>" + characters.c2.name + "</h4>");
                $("#3").append("<h4 id='h3'>" + characters.c3.name + "</h4>");
                $("#4").append("<h4 id='h4'>" + characters.c4.name + "</h4>");

                //char details and buttons
                $("#h1").after("<button type='button' id='chooseBtn1'class='btn btn-success'>Choose trump</button>").after("<p>Health " + characters.c1.health + "</p>").after(characters.c1.tagline).after("<img class='img-responsive center-block img-sz-3' id='img1' src='" + characters.c1.imgSrc + "'>");
                $("#h2").after("<button type='button' id='chooseBtn2'class='btn btn-success'>Choose Pussy</button>").after("<p>Health " + characters.c2.health + "</p>").after(characters.c2.tagline).after("<img class='img-responsive center-block img-sz-3' id='img2' src='" + characters.c2.imgSrc + "'>");
                $("#h3").after("<button type='button' id='chooseBtn3'class='btn btn-success'>Choose Hombre</button>").after("<p>Health " + characters.c3.health + "</p>").after(characters.c3.tagline).after("<img class='img-responsive center-block img-sz-3' id='img3' src='" + characters.c3.imgSrc + "'>");
                $("#h4").after("<button type='button' id='chooseBtn4'class='btn btn-success'>Choose Mika</button>").after("<p>Health " + characters.c4.health + "</p>").after(characters.c4.tagline).after("<img class='img-responsive center-block img-sz-3' id='img4' src='" + characters.c4.imgSrc + "'>");

                //close.each
            }

            initialRender = false;
        },

        //click events
        whenClicked: function() {
            $(".btn").on("click", function() {
                clickedBtn = this.id;
                console.log(clickedBtn);
                return clickedBtn;
            })
        },

        //click handlers
        handleClicks: function(getClicked) {
            console.log(getClicked);
        },
    }

    //character1-4 objects
    var characters = {
        c1: {
            colID: 1,
            name: "trump",
            tagline: "just. simply. the best.",
            imgSrc: "https://media.giphy.com/media/CrcVLCRcwXJmg/giphy.gif",
            buttonText: "Choose trump",
            health: 100,
            attack: 2,
            attackGain: this.attack * 1.1
        },
        c2: {
            colID: 2,
            name: "Pussy",
            tagline: "just grab it.",
            imgSrc: "https://media4.giphy.com/media/5i7umUqAOYYEw/giphy.gif",
            buttonText: "Choose Pussy",
            health: 200,
            attack: 25,
            attackGain: this.attack * 2
        },
        c3: {
            colID: 3,
            name: "Bad Hombre",
            tagline: "great at scaling vertical obstacles",
            imgSrc: "https://media.giphy.com/media/j2nYebu8Fc62Y/giphy.gif",
            buttonText: "Choose Bad Hombre",
            health: 150,
            attack: 17,
            attackGain: this.attack * 1.7
        },
        c4: {
            colID: 4,
            name: "Fake News Reporter",
            tagline: "all lies",
            imgSrc: "https://media2.giphy.com/media/JGX6u6mtPD0Oc/giphy.gif",
            buttonText: "Choose Mika",
            health: 130,
            attack: 10,
            attackGain: this.attack * 1.4
        }
    }

    fight.init();
    console.log(fight);
})
