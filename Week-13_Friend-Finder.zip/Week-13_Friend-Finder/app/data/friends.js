var newFriend = [
    {
    friendName: "kat",
    frindPhoto: "katsphoto.html",
    q1: 1,
    q2: 2,
    q3: 3,
    q4: 4,
    q5: 5,
    q6: 4,
    q7: 3,
    q8: 2,
    q9: 1,
    q10: 1
  }
];

  module.exports = newFriend;